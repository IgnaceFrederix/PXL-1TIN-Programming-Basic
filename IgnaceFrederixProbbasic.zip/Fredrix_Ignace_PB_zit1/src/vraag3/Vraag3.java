package vraag3;

import java.util.Scanner;

public class Vraag3 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int getal;
		getal=1;
		String tekst;
		StringBuilder spatie = new StringBuilder();
		int pos;
		int teller;
		teller =1;
		String tekst2;
		while(getal > 0)
		{
			System.out.println("geef een tekst in");
			tekst = input.nextLine();
			System.out.println("geef een lengte in");
			getal = input.nextInt();
			input.nextLine();
			tekst = tekst.trim();
			for(int i = 0; i < getal; i++)
			{
				System.out.print("-");
			}
			System.out.println();
			if(tekst.length() >= getal)
			{
				tekst = tekst.replace(" ", "\n");
				pos = tekst.indexOf("\n");
				
				while(pos != -1)
				{
				
				for(int i = tekst.indexOf("\n") ; i < getal; i++)
				{
					spatie = spatie.append(" ");
					teller++;
					pos = spatie.indexOf(" \n",pos+1);
				}
				pos = tekst.indexOf("\n"+1);
				//pos = tekst.indexOf("\n",pos+1);				
				}
				spatie.append(tekst);
				System.out.println(spatie);
				System.out.println(tekst.indexOf("\n"));
				
		
			}else{
				
				for(int i = tekst.length(); i < getal; i++){
					spatie = spatie.append(" ");
				}
				spatie.append(tekst);
				System.out.println(spatie);
			}
		}
		
		
		
input.close();
	}
	

}
