package vraag2;

import java.math.BigInteger;

public class Vraag2 {

	public static void main(String[] args) {
		long  getal;
		getal=1;
		
		byte [] getallen = new byte [1];
		BigInteger big = new BigInteger(getallen);
		for(byte i = 1; i < 101; i++)
		{
			getal = getal*i;
			
		
			
		}
		getallen[0]= (byte)getal;
		System.out.println(big);
		System.out.println(getal);
	}

}
